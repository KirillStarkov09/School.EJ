<?php
#
# $Id: footer.php 11 2010-03-20 21:11:22Z kuzmich $
#

?>
<br />
<div align="center">
<table border="0" cellspacing="0" cellpadding="0" class="table_menu">
  <tr>
    <td><img src="../images/circle_left_top.gif" alt="" width="6" height="6"></td>
    <td valign="top" class="border_top"><img src="../images/border.gif" alt="" width="1" height="1"></td>
    <td><img src="../images/circle_right_top.gif" alt="" width="6" height="6"></td>
  </tr>
  <tr>
    <td class="border_left">&nbsp;</td>
    <td class="padding" align="center"> <br /><nowrap>����: <a href="http://www.my-edu.ru/">���� ������</a>, ����������: <a href="http://www.kuzin.name">����� ������</a>, ��� ���������: <a href="http://www.name4yoursite.ru">Name4YourSite.Ru</a></nowrap><br /><br /></td>
    <td class="border_right">&nbsp;</td>
  </tr>
  <tr>
    <td><img src="../images/circle_left_bottom.gif" alt="" width="6" height="6"></td>
    <td width="99%" valign="bottom" class="border_bottom"><img src="../images/border.gif" alt="" width="1" height="1"></td>
    <td><img src="../images/circle_right_bottom.gif" alt="" width="6" height="6"></td>
  </tr>
</table>
</div>
  </body>
</html>