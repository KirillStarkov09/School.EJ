<?php
#
# $Id: header_dialog.php 19 2010-04-04 08:57:11Z kuzmich $
#

?>
<html>
  <head>
    <script type="text/javascript" src="../js/jquery.js"></script>
    <script type="text/javascript" src="../js/jquery-ui.js"></script>
    <script type="text/javascript" src="../js/i18n/jquery-ui.datepicker-ru.js"></script>
    <script type="text/javascript" src="../js/jquery.validate.js"></script>
    <script type="text/javascript" src="../js/i18n/jquery.validate-ru.js"></script>
    <script type="text/javascript" src="../js/jquery.maskedinput.js"></script>
    <script type="text/javascript" src="../js/thickbox.js"></script>
    <link rel="stylesheet" type="text/css" href="../ui-theme/<?php echo $config['ui']['theme']?>/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="../thickbox.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="../style.css" />
  </head>
